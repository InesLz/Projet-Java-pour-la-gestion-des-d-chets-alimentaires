package project;
import java.sql.*;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JButton;
import javax.swing.ImageIcon;
import javax.swing.JTextArea;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class AdminLogin {

	 JFrame secondframe;
	 JTextArea txtrAdministrateur = new JTextArea();
	 JTextArea txtrMotDePasse = new JTextArea();



	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AdminLogin window = new AdminLogin();
					window.secondframe.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public AdminLogin() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		secondframe = new JFrame();
		secondframe.setBounds(100, 100, 622, 446);
		secondframe.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		secondframe.getContentPane().setLayout(null);
		
		JButton btnNewButton = new JButton("Back");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Home h= new Home();
				h.frame.setVisible(true);
				secondframe.dispose();
			}
		});
		
		JButton btnNewButton_1 = new JButton("go");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					Class.forName("com.mysql.jdbc.Driver");
					Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/test","root","");
					Statement stmt= con.createStatement();
					String sql="Select * from adminlogins where Username='"+txtrAdministrateur.getText()+"' and  Password='"+txtrMotDePasse.getText()+"'";
					ResultSet rs= stmt.executeQuery(sql);
					if (rs.next()) {
						JOptionPane.showMessageDialog(null, "Logged in successfully...");
						WelcomeAdmin wa= new WelcomeAdmin();
						wa.fifthframe.setVisible(true);
						secondframe.dispose();
					}
					else {
						JOptionPane.showMessageDialog(null, "Incorrect information");
					}
					con.close();
				}
				catch(Exception ex) {
					System.out.println(ex);
				}
			}
			
		});
		btnNewButton_1.setBounds(394, 255, 89, 23);
		secondframe.getContentPane().add(btnNewButton_1);
		
		
		btnNewButton.setBounds(517, 384, 89, 23);
		secondframe.getContentPane().add(btnNewButton);
		
		txtrAdministrateur.setText("      Administrateur");
		txtrAdministrateur.setBounds(272, 89, 211, 22);
		secondframe.getContentPane().add(txtrAdministrateur);
		
		txtrMotDePasse.setText("       Mot de passe");
		txtrMotDePasse.setBounds(272, 152, 211, 22);
		secondframe.getContentPane().add(txtrMotDePasse);
		JLabel lblNewLabel = new JLabel("New label");
		lblNewLabel.setIcon(new ImageIcon("C:\\Users\\lenovo\\Desktop\\Java\\backgrounds\\second.PNG"));
		lblNewLabel.setBounds(0, 0, 606, 407);
		secondframe.getContentPane().add(lblNewLabel);
	}
}
