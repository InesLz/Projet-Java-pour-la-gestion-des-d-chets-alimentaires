package project;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.ImageIcon;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.awt.event.ActionEvent;

public class AjoutResponsable {

	 JFrame rframe;
	 JTextField txtUsername;
	 JTextField txtPassword;
	 JTextField txtNumroPointDe;
	 private JButton btnNewButton_1;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AjoutResponsable window = new AjoutResponsable();
					window.rframe.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public AjoutResponsable() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		rframe = new JFrame();
		rframe.setBounds(100, 100, 606, 407);
		rframe.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		rframe.getContentPane().setLayout(null);
		
		JButton btnNewButton = new JButton("Ajouter");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			try {
				// Connection cnx=cnx();
				 Connection con=dbb.getConnection();
				 String reqaj="insert into pointvente values (?,?,?)";
		    	   //String reqaj="delete into  values (?,?)";
		    	   PreparedStatement aj=con.prepareStatement(reqaj);
		    	  // Statement aj=cnx.Statemnent(reqaj);
		    	   aj.setString(1, txtUsername.getText());
		    	   aj.setString(2, txtPassword.getText());
		    	   aj.setString(3, txtNumroPointDe.getText());

		    	   aj.execute();
					Statement stmt=con.createStatement();

					ResultSet rs=stmt.executeQuery("show databases");

		    	   if (rs.next()) {
						JOptionPane.showMessageDialog(null, "Responsable de point de vente ajouté");
						txtUsername.setText("Username");
						txtPassword.setText("Password");
						txtNumroPointDe.setText("Numéro point de vente");
						
					}
				
					con.close();
					

				}catch(Exception e1){System.out.print(e1);}
				
			}
		});
		
		btnNewButton_1 = new JButton("Back");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				CréerDesComptes c = new CréerDesComptes();
				c.frmCrerDesComptes.setVisible(true);
				rframe.dispose();
			}
		});
		btnNewButton_1.setBounds(10, 25, 89, 23);
		rframe.getContentPane().add(btnNewButton_1);
		btnNewButton.setBounds(491, 317, 89, 23);
		rframe.getContentPane().add(btnNewButton);
		
		txtNumroPointDe = new JTextField();
		txtNumroPointDe.setText(" Numéro point de vente");
		txtNumroPointDe.setBounds(262, 224, 124, 20);
		rframe.getContentPane().add(txtNumroPointDe);
		txtNumroPointDe.setColumns(10);
		
		txtUsername = new JTextField();
		txtUsername.setText("           Username");
		txtUsername.setBounds(262, 90, 124, 20);
		rframe.getContentPane().add(txtUsername);
		txtUsername.setColumns(10);
		
		txtPassword = new JTextField();
		txtPassword.setText("          Password");
		txtPassword.setBounds(262, 150, 124, 20);
		rframe.getContentPane().add(txtPassword);
		txtPassword.setColumns(10);
		
		JLabel lblNewLabel = new JLabel("New label");
		lblNewLabel.setIcon(new ImageIcon("C:\\Users\\lenovo\\Desktop\\Java\\backgrounds\\b7.PNG"));
		lblNewLabel.setBounds(0, 0, 590, 368);
		rframe.getContentPane().add(lblNewLabel);
	}
}
