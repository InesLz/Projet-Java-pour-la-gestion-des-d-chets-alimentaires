package project;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.ImageIcon;

public class Home {

	 JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Home window = new Home();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Home() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 622, 446);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JButton btnNewButton = new JButton("Administrateur");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				AdminLogin al= new AdminLogin();
				al.secondframe.setVisible(true);
				frame.dispose();
			}
		});
		
		JButton btnNewButton_2 = new JButton("Responsable de point de vente\r\n");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ResponsablePointVente rp = new ResponsablePointVente();
				rp.fourthframe.setVisible(true);
				frame.dispose();
			}
		});
		btnNewButton_2.setBounds(225, 180, 211, 23);
		frame.getContentPane().add(btnNewButton_2);
		
		JButton btnNewButton_1 = new JButton("Propriétaire de restaurant");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				PropriétaireDeRestaurant pr= new PropriétaireDeRestaurant();
				pr.thirdframe.setVisible(true);
				frame.dispose();
			}
		});
		btnNewButton_1.setBounds(225, 127, 211, 23);
		frame.getContentPane().add(btnNewButton_1);
		btnNewButton.setBounds(225, 71, 211, 23);
		frame.getContentPane().add(btnNewButton);
		
		JLabel lblNewLabel = new JLabel("New label");
		lblNewLabel.setIcon(new ImageIcon("C:\\Users\\lenovo\\Desktop\\Java\\backgrounds\\first.PNG"));
		lblNewLabel.setBounds(0, 0, 606, 407);
		frame.getContentPane().add(lblNewLabel);
	}
}
