package project;

import java.sql.*;

import javax.swing.DefaultListModel;
import javax.swing.JList;

public class methode {
	
	public void fillDataJList (JList list) {
		try {
			DefaultListModel model = new DefaultListModel();
			 Connection con=dbb.getConnection();
			 Statement stmt= con.createStatement();
			ResultSet rs=stmt.executeQuery("SELECT * FROM pointvente");
			while(rs.next()) {
				String adr = rs.getString("Adresse");
				model.addElement(adr);
			}
			list.setModel(model);

		}
		catch (SQLException ex) {
			System.out.println(ex);
		}
		
	}

}
