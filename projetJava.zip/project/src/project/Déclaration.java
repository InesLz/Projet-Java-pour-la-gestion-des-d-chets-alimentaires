package project;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import javax.swing.JTextField;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JFormattedTextField;
import javax.swing.DropMode;
import com.toedter.calendar.JCalendar;
import com.toedter.calendar.JDayChooser;
import com.toedter.calendar.JDateChooser;
import javax.swing.border.CompoundBorder;
import javax.swing.border.LineBorder;
import java.awt.Color;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.awt.event.ActionEvent;

public class Déclaration {

	 JFrame dframe;
	 JTextField txtWriteYourMessage = new JTextField();
	 JList list = new JList();
	 JDateChooser dateChooser = new JDateChooser();
	 String theDate = dateChooser.getDateFormatString();
	 methode methode = new methode ();
	 private JTextField txtTaperVotrePoint = new JTextField();
	 private final JButton btnEnvoyerUnMessage = new JButton("Envoyer Un Message");
	 

	 

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Déclaration window = new Déclaration();
					window.dframe.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Déclaration() {
		initialize();
		methode.fillDataJList(list);
		btnEnvoyerUnMessage.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					// Connection cnx=cnx();
					 Connection con=db.getConnection();
					 String reqaj="insert into messages values (?)";
			    	   //String reqaj="delete into  values (?,?)";
			    	   PreparedStatement aj=con.prepareStatement(reqaj);
			    	  // Statement aj=cnx.Statemnent(reqaj);
			    	   
			    	   aj.setString(1, txtWriteYourMessage.getText());

			    	   aj.execute();
						Statement stmt=con.createStatement();

						ResultSet rs=stmt.executeQuery("show databases");

			    	   if (rs.next()) {
							JOptionPane.showMessageDialog(null, "Message envoyé");
							
							
						}
					
						con.close();
						

					}catch(Exception e1){
						System.out.print(e1);
						}
					
				}
			
		});
		btnEnvoyerUnMessage.setBounds(385, 317, 178, 23);
		
		dframe.getContentPane().add(btnEnvoyerUnMessage);
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		dframe = new JFrame();
		dframe.setTitle("faire une déclaration");
		dframe.setBounds(100, 100, 606, 407);
		dframe.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		dframe.getContentPane().setLayout(null);
		
		JButton btnNewButton = new JButton("Ajouter");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e)  {
				try {
					// Connection cnx=cnx();
					 Connection con=db.getConnection();
					 String reqaj="insert into déclaration values (?,?,?)";
			    	   //String reqaj="delete into  values (?,?)";
			    	   PreparedStatement aj=con.prepareStatement(reqaj);
			    	  // Statement aj=cnx.Statemnent(reqaj);
			    	   aj.setString(1, ((JTextField)dateChooser.getDateEditor().getUiComponent()).getText());
			    	   aj.setString(2, txtTaperVotrePoint.getText());
			    	   aj.setString(3, txtWriteYourMessage.getText());

			    	   
			    	   aj.execute();
						Statement stmt=con.createStatement();

						ResultSet rs=stmt.executeQuery("show databases");

			    	   if (rs.next()) {
							JOptionPane.showMessageDialog(null, "Déclaration envoyée");
							
							
						}
					
						con.close();
						

					}catch(Exception e1){
						System.out.print(e1);
						}
					
				}
		});
		
		txtTaperVotrePoint = new JTextField();
		txtTaperVotrePoint.setText("choisir votre point de vente");
		txtTaperVotrePoint.setBounds(39, 56, 178, 20);
		dframe.getContentPane().add(txtTaperVotrePoint);
		txtTaperVotrePoint.setColumns(10);
		btnNewButton.setBounds(39, 317, 178, 23);
		dframe.getContentPane().add(btnNewButton);
		
		txtWriteYourMessage.setText("                               \r\n\r\n\r\n\t\t\t envoyer un message au responsable de point de vente");
		txtWriteYourMessage.setBounds(357, 76, 223, 202);
		dframe.getContentPane().add(txtWriteYourMessage);
		txtWriteYourMessage.setColumns(10);
		list.setLayoutOrientation(JList.VERTICAL_WRAP);
		list.setBackground(new Color(250, 230, 251));
		list.setBorder(new CompoundBorder(new LineBorder(new Color(0, 0, 0), 2), null));
		
		list.setBounds(39, 87, 178, 191);
		dframe.getContentPane().add(list);
		
		
		dateChooser.setDateFormatString("yyyy-MM-dd");
		dateChooser.setBounds(39, 11, 178, 20);
		dframe.getContentPane().add(dateChooser);
	}
}
