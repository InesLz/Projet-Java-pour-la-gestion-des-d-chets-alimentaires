package project;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class WelcomeAdmin {

	 JFrame fifthframe;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					WelcomeAdmin window = new WelcomeAdmin();
					window.fifthframe.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public WelcomeAdmin() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		fifthframe = new JFrame();
		fifthframe.setBounds(100, 100, 622, 446);
		fifthframe.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		fifthframe.getContentPane().setLayout(null);
		
		JButton btnNewButton = new JButton("Next");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				FirstPageAdmin fpa = new FirstPageAdmin();
				fpa.fpaframe.setVisible(true);
				fifthframe.dispose();
				
			}
		});
		btnNewButton.setIcon(null);
		btnNewButton.setBounds(256, 352, 89, 23);
		fifthframe.getContentPane().add(btnNewButton);
		
		JLabel lblNewLabel = new JLabel("New label");
		lblNewLabel.setIcon(new ImageIcon("C:\\Users\\lenovo\\Desktop\\Java\\backgrounds\\dthird.PNG"));
		lblNewLabel.setBounds(0, 0, 606, 407);
		fifthframe.getContentPane().add(lblNewLabel);
	}
}
