package project;

import java.awt.EventQueue;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.*;

import javax.swing.JFrame;

public class db {
	public static Connection getConnection() {
		Connection con=null;
	//	Connection conn = null;
      //  Statement stmt = null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/responsableresto","root","");
			Statement stmt=con.createStatement();
			Statement st=con.createStatement();
			ResultSet rs=stmt.executeQuery("show databases");
			System.out.println("connected");
			
	}		
		catch(Exception e) {System.out.println(e);}
		return con;
		
	}

}
