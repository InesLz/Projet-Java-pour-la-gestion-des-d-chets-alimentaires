package project;

import java.awt.Color;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRootPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import javax.swing.JTextField;
import javax.swing.JButton;
import com.toedter.calendar.JDateChooser;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.awt.event.ActionEvent;

public class CréerUnBesoin {

	 JFrame plframe;
	 JTextField txtProduit = new JTextField() ;
	 JTextField txtQuantit = new JTextField();
	  JDateChooser dateChooser = new JDateChooser();


	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					CréerUnBesoin window = new CréerUnBesoin();
					window.plframe.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public CréerUnBesoin() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		 JFrame plframe = new JFrame();
		 plframe.setAlwaysOnTop(true);
		  plframe.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		  JPanel panel = new JPanel();
		  String data[][] = {{"tomate","100","demain"}};
		  String col[] = {"Produit","Quantité","date limite"};
		  DefaultTableModel model = new DefaultTableModel(data,col);
		  JTable table = new JTable(model);
		  JTableHeader header = table.getTableHeader();
		  header.setBackground(Color.yellow);
		  panel.setLayout(null);
		  
		  JButton btnNewButton = new JButton("Ajouter le besoin");
		  btnNewButton.addActionListener(new ActionListener() {
		  	public void actionPerformed(ActionEvent e) {
		  		try {
					// Connection cnx=cnx();
					 Connection con=dbb.getConnection();
					 String reqaj="insert into besoin values (?,?,?)";
			    	   //String reqaj="delete into  values (?,?)";
			    	   PreparedStatement aj=con.prepareStatement(reqaj);
			    	  // Statement aj=cnx.Statemnent(reqaj);
			    	   aj.setString(1, txtProduit.getText());
			    	   aj.setString(2, txtQuantit.getText());
			    	   aj.setString(3, ((JTextField)dateChooser.getDateEditor().getUiComponent()).getText());
			    	   aj.execute();
						Statement stmt=con.createStatement();

						ResultSet rs=stmt.executeQuery("show databases");

			    	   if (rs.next()) {
							JOptionPane.showMessageDialog(null, "Besoin ajouté");
							
							
						}
					
						con.close();
						

					}catch(Exception e1){System.out.print(e1);}
				}
		  	
		  });
		  
		  JButton btnNewButton_1 = new JButton("go back");
		  btnNewButton_1.addActionListener(new ActionListener() {
		  	public void actionPerformed(ActionEvent e) {
		  		FirstPageResponsable fr = new FirstPageResponsable();
				fr.frame.setVisible(true);
				plframe.dispose();
		  	}
		  });
		  btnNewButton_1.setBounds(30, 359, 220, 26);
		  panel.add(btnNewButton_1);
		  btnNewButton.setBounds(30, 278, 220, 26);
		  panel.add(btnNewButton);
		  JScrollPane pane = new JScrollPane(table);
		  pane.setBounds(284, 43, 326, 342);
		  panel.add(pane);
		  plframe.getContentPane().add(panel);
		  
		  txtProduit.setText("Produit");
		  txtProduit.setBounds(30, 71, 114, 20);
		  panel.add(txtProduit);
		  txtProduit.setColumns(10);
		  
		  txtQuantit.setText("Quantité");
		  txtQuantit.setBounds(30, 127, 114, 20);
		  panel.add(txtQuantit);
		  txtQuantit.setColumns(10);
		  
			dateChooser.setDateFormatString("yyyy-MM-dd");

		  dateChooser.setBounds(30, 182, 114, 20);
		  panel.add(dateChooser);
		  plframe.setUndecorated(true);
		  plframe.getRootPane().setWindowDecorationStyle(JRootPane.PLAIN_DIALOG);
		  plframe.setSize( 622, 446);
		  plframe.setVisible(true);  
		  }
}
