package project;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.ImageIcon;
import javax.swing.JTextField;



import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.awt.event.ActionEvent;

public class AjoutPropriétaire {

	 JFrame AjFrame;
	 JTextField txtUsername;
	 JTextField txtPassword;
	 JTextField txtAdresseRestaurant;
	 private final JButton btnBack = new JButton("back");

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AjoutPropriétaire window = new AjoutPropriétaire();
					window.AjFrame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public AjoutPropriétaire() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		AjFrame = new JFrame();
		AjFrame.setBounds(100, 100, 622, 446);
		AjFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		AjFrame.getContentPane().setLayout(null);
		
		JButton btnNewButton = new JButton("Ajouter");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					// Connection cnx=cnx();
					 Connection con=db.getConnection();
					 String reqaj="insert into restau values (?,?,?)";
			    	   //String reqaj="delete into  values (?,?)";
			    	   PreparedStatement aj=con.prepareStatement(reqaj);
			    	  // Statement aj=cnx.Statemnent(reqaj);
			    	   aj.setString(1, txtUsername.getText());
			    	   aj.setString(2, txtPassword.getText());
			    	   aj.setString(3, txtAdresseRestaurant.getText());

			    	   aj.execute();
						Statement stmt=con.createStatement();

						ResultSet rs=stmt.executeQuery("show databases");

			    	   if (rs.next()) {
							JOptionPane.showMessageDialog(null, "Responsable de restaurant ajouté");
							txtUsername.setText("Username");
							txtPassword.setText("Password");
							txtAdresseRestaurant.setText("Adresse");
							
						}
					
						con.close();
						

					}catch(Exception e1){System.out.print(e1);}
					}
			
		});
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				CréerDesComptes c = new CréerDesComptes();
				c.frmCrerDesComptes.setVisible(true);
				AjFrame.dispose();
				
			}
		});
		btnBack.setBounds(27, 318, 89, 31);
		AjFrame.getContentPane().add(btnBack);
		btnNewButton.setBounds(495, 318, 89, 23);
		AjFrame.getContentPane().add(btnNewButton);
		
		txtAdresseRestaurant = new JTextField();
		txtAdresseRestaurant.setText(" Adresse restaurant\r\n");
		txtAdresseRestaurant.setColumns(10);
		txtAdresseRestaurant.setBounds(285, 240, 105, 20);
		AjFrame.getContentPane().add(txtAdresseRestaurant);
		
		txtPassword = new JTextField();
		txtPassword.setText("         Password");
		txtPassword.setColumns(10);
		txtPassword.setBounds(285, 166, 105, 20);
		AjFrame.getContentPane().add(txtPassword);
		
		txtUsername = new JTextField();
		txtUsername.setText("        Username\r\n");
		txtUsername.setBounds(285, 106, 105, 20);
		AjFrame.getContentPane().add(txtUsername);
		txtUsername.setColumns(10);
		
		JLabel lblNewLabel = new JLabel("New label");
		lblNewLabel.setIcon(new ImageIcon("C:\\Users\\lenovo\\Desktop\\Java\\backgrounds\\b7.PNG"));
		lblNewLabel.setBounds(0, 0, 606, 407);
		AjFrame.getContentPane().add(lblNewLabel);
	}
}
