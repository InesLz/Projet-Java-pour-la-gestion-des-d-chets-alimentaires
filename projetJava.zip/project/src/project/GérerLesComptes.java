package project;

import java.awt.EventQueue;
import java.sql.*;

import javax.swing.JFrame;
import javax.swing.JButton;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

import java.awt.BorderLayout;
import javax.swing.JPanel;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.ImageIcon;
import java.awt.Color;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class GérerLesComptes {

	 JFrame loframe;
	 JTable table = new JTable();
	 DefaultTableModel model = new DefaultTableModel();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					GérerLesComptes window = new GérerLesComptes();
					window.loframe.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public GérerLesComptes() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		loframe = new JFrame();
		loframe.setBounds(100, 100, 768, 516);
		loframe.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		loframe.getContentPane().setLayout(null);
		
		JButton btnNewButton_2 = new JButton("Delete");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					Connection con=db.getConnection();
					Statement stmt= con.createStatement();
					String deleteSQL = "DELETE FROM restau WHERE ";
					PreparedStatement pstmt = con.prepareStatement(deleteSQL);
					pstmt.setString(1, "value");
					pstmt.executeUpdate();
					DefaultTableModel model = new DefaultTableModel();
					table.getModel();
					model.removeRow(table.getSelectedRow());

					} catch (SQLException ex) {
						System.out.println(ex);
					}
			}
		});
		
		btnNewButton_2.setBounds(46, 379, 152, 23);
		loframe.getContentPane().add(btnNewButton_2);
		
		JLabel lblNewLabel = new JLabel("Username");
		lblNewLabel.setForeground(Color.WHITE);
		lblNewLabel.setBounds(371, 25, 64, 14);
		loframe.getContentPane().add(lblNewLabel);
		
		table = new JTable();
		table.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				int index = table.getSelectedRow();
			       TableModel model = table.getModel();
			       String username = model.getValueAt(index,0).toString();
			       String password = model.getValueAt(index,1).toString();
			       int a = JOptionPane.showConfirmDialog(null, "Do you want to delete "+username+"","Select",JOptionPane.YES_NO_OPTION);
			       if (a == 0){
			           
			       }
			}
		});
		table.setBounds(371, 46, 349, 398);
		loframe.getContentPane().add(table);
		
		JButton btnNewButton = new JButton("Display Data");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
						Class.forName("com.mysql.jdbc.Driver");
						Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/responsableresto","root","");
						Statement st=con.createStatement();
						String query = "select * from restau";
						ResultSet rs = st.executeQuery(query);
						ResultSetMetaData rsmd = rs.getMetaData();
						DefaultTableModel model = (DefaultTableModel) table.getModel();
						int cols=rsmd.getColumnCount();
						String[] colName= new String [cols];
						for (int i=0; i<cols;i++) 
							colName[i]= rsmd.getColumnName(i+1);
						model.setColumnIdentifiers(colName);
						String DateDeclaration,PointVente,Message;
						while(rs.next()) {
							DateDeclaration=rs.getString(1);
							PointVente=rs.getString(2);
							Message=rs.getString(3);
							String[] row = {DateDeclaration,PointVente,Message};
							model.addRow(row);
							btnNewButton.setEnabled(false);
						}
						st.close();
						con.close();
						
					}
				catch (SQLException ex) {
					ex.printStackTrace();
					
				}
				 catch (ClassNotFoundException e1) {
					e1.printStackTrace();
				}
				}
			
		});
		btnNewButton.setBounds(46, 186, 152, 23);
		loframe.getContentPane().add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Clear");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				table.setModel(new DefaultTableModel());
				btnNewButton.setEnabled(true);

				
			}
		});
		btnNewButton_1.setBounds(46, 282, 152, 23);
		loframe.getContentPane().add(btnNewButton_1);
		
		JLabel lblNewLabel_1 = new JLabel("Password");
		lblNewLabel_1.setForeground(Color.WHITE);
		lblNewLabel_1.setBounds(488, 25, 64, 14);
		loframe.getContentPane().add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Adresse Restaurant");
		lblNewLabel_2.setForeground(Color.WHITE);
		lblNewLabel_2.setBounds(601, 25, 106, 14);
		loframe.getContentPane().add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("New label");
		lblNewLabel_3.setIcon(new ImageIcon("C:\\Users\\lenovo\\Desktop\\Java\\backgrounds\\c7.PNG"));
		lblNewLabel_3.setBounds(0, 0, 752, 477);
		loframe.getContentPane().add(lblNewLabel_3);
		
		JButton btnNewButton_4 = new JButton("New button");
		btnNewButton_4.setBounds(277, 72, 89, 23);
		loframe.getContentPane().add(btnNewButton_4);
	}
}
