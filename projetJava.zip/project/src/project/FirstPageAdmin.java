package project;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.util.*;

import java.sql.*;

public class FirstPageAdmin {

	 JFrame fpaframe;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					FirstPageAdmin window = new FirstPageAdmin();
					window.fpaframe.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public FirstPageAdmin() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		fpaframe = new JFrame();
		fpaframe.setBounds(100, 100, 622, 446);
		fpaframe.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		fpaframe.getContentPane().setLayout(null);
		
		JButton btnNewButton_2 = new JButton("Valider les besoins");
		btnNewButton_2.setBounds(374, 312, 148, 23);
		fpaframe.getContentPane().add(btnNewButton_2);
		
		JButton btnNewButton_1 = new JButton("Gérer les comptes");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				GérerLesComptes glc = new GérerLesComptes();
				glc.loframe.setVisible(true);
				fpaframe.dispose();
				
			}
		});
		
		btnNewButton_1.setBounds(374, 205, 148, 23);
		fpaframe.getContentPane().add(btnNewButton_1);
		
		JButton btnNewButton = new JButton("Créer des comptes");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				CréerDesComptes fc = new CréerDesComptes();
				fc.frmCrerDesComptes.setVisible(true);
				fpaframe.dispose();
				
			}
		});
		btnNewButton.setBounds(374, 96, 148, 23);
		fpaframe.getContentPane().add(btnNewButton);
		
		JLabel lblNewLabel = new JLabel("New label");
		lblNewLabel.setIcon(new ImageIcon("C:\\Users\\lenovo\\Desktop\\Java\\backgrounds\\d4.PNG"));
		lblNewLabel.setBounds(0, 0, 606, 407);
		fpaframe.getContentPane().add(lblNewLabel);
	}

}
