package project;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.JButton;
import java.awt.BorderLayout;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.awt.event.ActionEvent;

public class VisualiserLesMessages {

	 JFrame msgframe;
	 JTable table = new JTable();


	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					VisualiserLesMessages window = new VisualiserLesMessages();
					window.msgframe.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public VisualiserLesMessages() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		msgframe = new JFrame();
		msgframe.setBounds(100, 100, 645, 404);
		msgframe.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		msgframe.getContentPane().setLayout(null);
		
		JButton btnNewButton_1 = new JButton("go back");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				FirstPageResponsable fr = new FirstPageResponsable();
				fr.frame.setVisible(true);
				msgframe.dispose();
			}
		});
		btnNewButton_1.setBounds(10, 331, 89, 23);
		msgframe.getContentPane().add(btnNewButton_1);
		
		table = new JTable();
		table.setBounds(371, 46, 349, 398);
		msgframe.getContentPane().add(table);
		
		JButton btnNewButton = new JButton("voir les messages");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					Class.forName("com.mysql.jdbc.Driver");
					Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/responsableresto","root","");
					Statement st=con.createStatement();
					String query = "SELECT * FROM `messages` ORDER BY 'messages' DESC";
					ResultSet rs = st.executeQuery(query);
					ResultSetMetaData rsmd = rs.getMetaData();
					DefaultTableModel model = (DefaultTableModel) table.getModel();
					int cols=rsmd.getColumnCount();
					String[] colName= new String [cols];
					for (int i=0; i<cols;i++) 
						colName[i]= rsmd.getColumnName(i+1);
					model.setColumnIdentifiers(colName);
					String Message;
					while(rs.next()) {
						
						Message=rs.getString(1);
						String[] row = {Message};
						model.addRow(row);
						btnNewButton.setEnabled(false);
					}
					st.close();
					con.close();
					
				}
			catch (SQLException ex) {
				ex.printStackTrace();
				
			}
			 catch (ClassNotFoundException e1) {
				e1.printStackTrace();
			}
			}
		});
		btnNewButton.setBounds(34, 207, 128, 23);
		msgframe.getContentPane().add(btnNewButton);
	}
}
