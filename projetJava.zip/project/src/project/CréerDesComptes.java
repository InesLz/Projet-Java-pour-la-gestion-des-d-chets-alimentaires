package project;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class CréerDesComptes {

	 JFrame frmCrerDesComptes;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					CréerDesComptes window = new CréerDesComptes();
					window.frmCrerDesComptes.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public CréerDesComptes() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmCrerDesComptes = new JFrame();
		frmCrerDesComptes.setTitle("Créer des comptes");
		frmCrerDesComptes.setBounds(100, 100, 622, 446);
		frmCrerDesComptes.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmCrerDesComptes.getContentPane().setLayout(null);
		
		JButton btnNewButton_2_1 = new JButton("Responsable de point de vente");
		btnNewButton_2_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				AjoutResponsable arr = new AjoutResponsable();
				arr.rframe.setVisible(true);
				frmCrerDesComptes.dispose();

			}
			
		});
		
		JButton btnNewButton = new JButton("Back");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				FirstPageAdmin f = new FirstPageAdmin();
				f.fpaframe.setVisible(true);
				frmCrerDesComptes.dispose();
			}
		});
		btnNewButton.setBounds(27, 356, 89, 23);
		frmCrerDesComptes.getContentPane().add(btnNewButton);
		btnNewButton_2_1.setBounds(314, 159, 248, 23);
		frmCrerDesComptes.getContentPane().add(btnNewButton_2_1);
		
		JButton btnNewButton_2 = new JButton("Propriétaire de restaurant");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				AjoutPropriétaire aj = new AjoutPropriétaire();
				aj.AjFrame.setVisible(true);
				frmCrerDesComptes.dispose();
				
				
				
			}
		});
		btnNewButton_2.setBounds(27, 111, 262, 23);
		frmCrerDesComptes.getContentPane().add(btnNewButton_2);
		
		JLabel lblNewLabel = new JLabel("New label");
		lblNewLabel.setIcon(new ImageIcon("C:\\Users\\lenovo\\Desktop\\Java\\backgrounds\\b5.PNG"));
		lblNewLabel.setBounds(0, 0, 606, 407);
		frmCrerDesComptes.getContentPane().add(lblNewLabel);
	}
}
