package project;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.ImageIcon;
import javax.swing.JTextArea;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;

public class RestaurantLogin {

	  JFrame feframe;
	JTextArea txtRD = new JTextArea();
	 JTextArea txtRP = new JTextArea();


	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					RestaurantLogin window = new RestaurantLogin();
					window.feframe.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public RestaurantLogin() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		feframe = new JFrame();
		feframe.setBounds(100, 100, 622, 446);
		feframe.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		feframe.getContentPane().setLayout(null);
		
		JButton btnNewButton = new JButton("Se Connecter");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					Class.forName("com.mysql.jdbc.Driver");
					Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/responsableresto","root","");
					Statement stmt= con.createStatement();
					String sql="Select * from restau where Username='"+txtRD.getText()+"' and  Password='"+txtRP.getText()+"'";
					ResultSet rs= stmt.executeQuery(sql);
					if (rs.next()) {
						JOptionPane.showMessageDialog(null, "Logged in successfully...");
						WelcomeRestaurant wr= new WelcomeRestaurant();
						wr.lkframe.setVisible(true);
						feframe.dispose();
						
					}
					else {
						JOptionPane.showMessageDialog(null, "Incorrect information");
					}
					con.close();
				}
				catch(Exception ex) {
					System.out.println(ex);
				}
			}
			
		});
		btnNewButton.setBounds(394, 256, 122, 23);
		feframe.getContentPane().add(btnNewButton);
		
		txtRD.setText("Responsable de restaurant");
		txtRD.setBounds(305, 97, 211, 22);
		feframe.getContentPane().add(txtRD);
		
		txtRP.setText("Mot de passe");
		txtRP.setBounds(305, 163, 211, 22);
		feframe.getContentPane().add(txtRP);
		
		JLabel lblNewLabel = new JLabel("New label");
		lblNewLabel.setIcon(new ImageIcon("C:\\Users\\lenovo\\Desktop\\Java\\backgrounds\\second.PNG"));
		lblNewLabel.setBounds(0, 0, 606, 407);
		feframe.getContentPane().add(lblNewLabel);
	}
}
