package project;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class FirstPageRestaurant {

	 JFrame lllframe;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					FirstPageRestaurant window = new FirstPageRestaurant();
					window.lllframe.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public FirstPageRestaurant() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		lllframe = new JFrame();
		lllframe.setBounds(100, 100, 606, 407);
		lllframe.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		lllframe.getContentPane().setLayout(null);
		
		JButton btnNewButton_1 = new JButton("Visualiser l'historique");
		btnNewButton_1.setBounds(283, 227, 220, 23);
		lllframe.getContentPane().add(btnNewButton_1);
		
		JButton btnNewButton = new JButton("Faire une déclaration");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Déclaration d = new Déclaration();
				d.dframe.setVisible(true);
				lllframe.dispose();
			}
		});
		btnNewButton.setBounds(283, 141, 220, 23);
		lllframe.getContentPane().add(btnNewButton);
		
		JLabel lblNewLabel = new JLabel("New label");
		lblNewLabel.setIcon(new ImageIcon("C:\\Users\\lenovo\\Desktop\\Java\\backgrounds\\c6.PNG"));
		lblNewLabel.setBounds(0, 0, 590, 368);
		lllframe.getContentPane().add(lblNewLabel);
	}

}
