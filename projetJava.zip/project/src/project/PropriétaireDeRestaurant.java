package project;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JTextArea;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.awt.event.ActionEvent;

public class PropriétaireDeRestaurant {

	 JFrame thirdframe;
	 JTextArea txtrPropritaireDeRestaurant = new JTextArea();
	 JTextArea txtrMotDePasse = new JTextArea();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					PropriétaireDeRestaurant window = new PropriétaireDeRestaurant();
					window.thirdframe.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public PropriétaireDeRestaurant() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		thirdframe = new JFrame();
		thirdframe.setBounds(100, 100, 622, 443);
		thirdframe.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		thirdframe.getContentPane().setLayout(null);
		
		JButton btnNewButton_1 = new JButton("Se Connecter");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					Class.forName("com.mysql.jdbc.Driver");
					Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/responsableresto","root","");
					Statement stmt= con.createStatement();
					String sql="Select * from restau where Username='"+txtrPropritaireDeRestaurant.getText()+"' and  Password='"+txtrMotDePasse.getText()+"'";
					ResultSet rs= stmt.executeQuery(sql);
					if (rs.next()) {
						JOptionPane.showMessageDialog(null, "Logged in successfully...");
						WelcomeRestaurant w = new WelcomeRestaurant();
						w.lkframe.setVisible(true);
						thirdframe.dispose();
					}
					else {
						JOptionPane.showMessageDialog(null, "Incorrect information");
					}
					con.close();
				}
				catch(Exception ex) {
					System.out.println(ex);
				}
			}
			
		});
		btnNewButton_1.setBounds(375, 216, 103, 23);
		thirdframe.getContentPane().add(btnNewButton_1);
		
		txtrPropritaireDeRestaurant.setText("Propriétaire de restaurant");
		txtrPropritaireDeRestaurant.setBounds(267, 90, 211, 22);
		thirdframe.getContentPane().add(txtrPropritaireDeRestaurant);
		
		txtrMotDePasse.setText("       Mot de passe");
		txtrMotDePasse.setBounds(267, 154, 211, 22);
		thirdframe.getContentPane().add(txtrMotDePasse);
		
		JButton btnNewButton = new JButton("Back");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Home h = new Home();
				h.frame.setVisible(true);
				thirdframe.dispose();
			}
		});
		btnNewButton.setBounds(517, 381, 89, 23);
		thirdframe.getContentPane().add(btnNewButton);
		
		JLabel lblNewLabel = new JLabel("New label");
		lblNewLabel.setIcon(new ImageIcon("C:\\Users\\lenovo\\Desktop\\Java\\backgrounds\\backgrounds\\second.PNG"));
		lblNewLabel.setBounds(0, 0, 606, 404);
		thirdframe.getContentPane().add(lblNewLabel);
	}

}
