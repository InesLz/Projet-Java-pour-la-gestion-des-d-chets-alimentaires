package project;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.ImageIcon;
import javax.swing.JTextArea;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;

public class ResponsablePointVente {

	    JFrame fourthframe;
		JTextArea txtrMotDePasse_1 = new JTextArea();
		JTextArea txtrResponsableDePoint = new JTextArea();
		 JTextArea txtNumroDuPoint;



	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ResponsablePointVente window = new ResponsablePointVente();
					window.fourthframe.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public ResponsablePointVente() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		fourthframe = new JFrame();
		fourthframe.setBounds(100, 100, 624, 444);
		fourthframe.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		fourthframe.getContentPane().setLayout(null);
		
		JButton btnNewButton = new JButton("Back\r\n");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Home h = new Home();
				h.frame.setVisible(true);
				fourthframe.dispose();
			}
		});
		
		JButton btnNewButton_1 = new JButton("Se Connecter");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					Class.forName("com.mysql.jdbc.Driver");
					Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/responsablevente","root","");
					Statement stmt= con.createStatement();
					String sql="Select * from pointvente where Username='"+txtrResponsableDePoint.getText()+"' and  Password='"+txtrMotDePasse_1.getText()+"' and Adresse='"+txtNumroDuPoint.getText()+"'";
					ResultSet rs= stmt.executeQuery(sql);
					if (rs.next()) {
						JOptionPane.showMessageDialog(null, "Logged in successfully...");
						FirstPageResponsable fp= new FirstPageResponsable();
						fp.frame.setVisible(true);
						fourthframe.dispose();
					}
					else {
						JOptionPane.showMessageDialog(null, "Incorrect information");
					}
					con.close();
				}
				catch(Exception ex) {
					System.out.println(ex);
				}
			}
		});
		
		txtNumroDuPoint = new JTextArea();
		txtNumroDuPoint.setText("  Numéro du point de vente");
		txtNumroDuPoint.setBounds(361, 176, 237, 20);
		fourthframe.getContentPane().add(txtNumroDuPoint);
		txtNumroDuPoint.setColumns(10);
		btnNewButton_1.setBounds(412, 257, 186, 23);
		fourthframe.getContentPane().add(btnNewButton_1);
		btnNewButton.setBounds(509, 371, 89, 23);
		fourthframe.getContentPane().add(btnNewButton);
		
		txtrMotDePasse_1.setText("        Mot de passe");
		txtrMotDePasse_1.setBounds(361, 106, 237, 22);
		fourthframe.getContentPane().add(txtrMotDePasse_1);
		
		txtrResponsableDePoint.setText("Responsable de point de vente");
		txtrResponsableDePoint.setBounds(361, 38, 237, 22);
		fourthframe.getContentPane().add(txtrResponsableDePoint);
		
		JLabel lblNewLabel = new JLabel("New label");
		lblNewLabel.setIcon(new ImageIcon("C:\\Users\\lenovo\\Desktop\\Java\\backgrounds\\second.PNG"));
		lblNewLabel.setBounds(0, 0, 608, 405);
		fourthframe.getContentPane().add(lblNewLabel);
	}

}
