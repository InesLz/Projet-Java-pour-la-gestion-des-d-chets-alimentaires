package project;

import java.awt.EventQueue;
import java.sql.*;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;

public class FirstPageResponsable {

	 JFrame frame;
	 JTextField txtConfirmer = new JTextField();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					FirstPageResponsable window = new FirstPageResponsable();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public FirstPageResponsable() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 606, 407);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JButton btnNewButton_3 = new JButton("Log out");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Home h = new Home();
				h.frame.setVisible(true);
				frame.dispose();
			}
		});
		btnNewButton_3.setBounds(431, 322, 149, 23);
		frame.getContentPane().add(btnNewButton_3);
		
		txtConfirmer = new JTextField();
		txtConfirmer.setText("Confirmer votre point de vente");
		txtConfirmer.setBounds(409, 116, 86, 20);
		frame.getContentPane().add(txtConfirmer);
		txtConfirmer.setColumns(10);
		
		JButton btnNewButton_1 = new JButton("Visualiser les messages");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

			VisualiserLesMessages msg = new VisualiserLesMessages();
			msg.msgframe.setVisible(true);
			frame.dispose();
			}
			
		});
		btnNewButton_1.setBounds(74, 136, 149, 23);
		frame.getContentPane().add(btnNewButton_1);
		
		JButton btnNewButton = new JButton("Créer un besoin");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				CréerBesoin cb = new CréerBesoin();
				 cb.bbbframe.setVisible(true);
				 frame.dispose();
			}
		});
		btnNewButton.setBounds(74, 62, 149, 23);
		frame.getContentPane().add(btnNewButton);
		
		JButton btnNewButton_2 = new JButton("Envoyer des messages");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnNewButton_2.setBounds(74, 206, 149, 23);
		frame.getContentPane().add(btnNewButton_2);
		
		JLabel lblNewLabel = new JLabel("New label");
		lblNewLabel.setIcon(new ImageIcon("C:\\Users\\lenovo\\Desktop\\Java\\backgrounds\\c1.PNG"));
		lblNewLabel.setBounds(-66, 0, 682, 368);
		frame.getContentPane().add(lblNewLabel);
	}
}
