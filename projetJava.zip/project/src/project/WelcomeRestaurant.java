package project;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class WelcomeRestaurant {

	 JFrame lkframe;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					WelcomeRestaurant window = new WelcomeRestaurant();
					window.lkframe.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public WelcomeRestaurant() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		lkframe = new JFrame();
		lkframe.setBounds(100, 100, 622, 446);
		lkframe.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		lkframe.getContentPane().setLayout(null);
		
		JButton btnNewButton = new JButton("Suivant");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				FirstPageRestaurant r = new FirstPageRestaurant();
				r.lllframe.setVisible(true);
				lkframe.dispose();
			}
		});
		btnNewButton.setBounds(495, 355, 89, 23);
		lkframe.getContentPane().add(btnNewButton);
		
		JLabel lblNewLabel = new JLabel("New label");
		lblNewLabel.setIcon(new ImageIcon("C:\\Users\\lenovo\\Desktop\\Java\\backgrounds\\c4.PNG"));
		lblNewLabel.setBounds(-69, 0, 689, 407);
		lkframe.getContentPane().add(lblNewLabel);
	}

}
