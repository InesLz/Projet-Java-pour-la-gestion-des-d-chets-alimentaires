package project;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import com.toedter.calendar.JDateChooser;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.awt.event.ActionEvent;
import javax.swing.JButton;

public class CréerBesoin {

	 JFrame bbbframe;
	 JTextField txtProduit = new JTextField();
	 JTextField txtQuantit = new JTextField();
	 JButton btnNewButton;
	 JDateChooser dateChooser = new JDateChooser();


	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					CréerBesoin window = new CréerBesoin();
					window.bbbframe.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public CréerBesoin() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		bbbframe = new JFrame();
		bbbframe.setBounds(100, 100, 606, 407);
		bbbframe.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		bbbframe.getContentPane().setLayout(null);
		
		btnNewButton = new JButton("Ajouter votre besoin");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
		  		try {
					// Connection cnx=cnx();
					 Connection con=dbb.getConnection();
					 String reqaj="insert into besoin values (?,?,?)";
			    	   //String reqaj="delete into  values (?,?)";
			    	   PreparedStatement aj=con.prepareStatement(reqaj);
			    	  // Statement aj=cnx.Statemnent(reqaj);
			    	   aj.setString(1, txtProduit.getText());
			    	   aj.setString(2, txtQuantit.getText());
			    	   aj.setString(3, ((JTextField)dateChooser.getDateEditor().getUiComponent()).getText());
			    	   aj.execute();
						Statement stmt=con.createStatement();

						ResultSet rs=stmt.executeQuery("show databases");

			    	   if (rs.next()) {
							JOptionPane.showMessageDialog(null, "Besoin ajouté");
							txtProduit.setText("Produit");
							txtQuantit.setText("Quantité");
							
							
						}
					
						con.close();
						

					}catch(Exception e1){System.out.print(e1);}
				}
		});
		btnNewButton.setBounds(41, 244, 170, 23);
		bbbframe.getContentPane().add(btnNewButton);
		
		txtProduit = new JTextField();
		txtProduit.setText("Produit");
		txtProduit.setBounds(41, 37, 86, 20);
		bbbframe.getContentPane().add(txtProduit);
		txtProduit.setColumns(10);
		
		txtQuantit = new JTextField();
		txtQuantit.setText("Quantité");
		txtQuantit.setBounds(41, 89, 86, 20);
		bbbframe.getContentPane().add(txtQuantit);
		txtQuantit.setColumns(10);
		
		dateChooser.getCalendarButton().addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		dateChooser.setBounds(41, 147, 86, 20);
		bbbframe.getContentPane().add(dateChooser);
	}
}
